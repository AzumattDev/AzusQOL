> # Update Information (Latest listed first)

| `Version` | `Update Notes`                                                                                                                                                                     |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.20    | - Remove OdinsInventoryDiscard, update Max Dungeon Rooms                                                                                                                           |
| 1.0.19    | - Update AzuCraftyBoxes                                                                                                                                                            |
| 1.0.18    | - Update Jotunn and AzuCraftyBoxes                                                                                                                                                 |
| 1.0.17    | - Update pretty much all of the mods after 0.216.9 Valheim Update                                                                                                                  |
| 1.0.16    | - Update Jotunn, Recipe Description Expansion, FastLink and AzuCraftyBoxes.                                                                                                        |
| 1.0.15    | - CraftyBoxes update.                                                                                                                                                              |
| 1.0.14    | - MiscPatches update.                                                                                                                                                              |
| 1.0.13    | - HoverStats update                                                                                                                                                                |
| 1.0.12    | - ACB update again                                                                                                                                                                 |
| 1.0.11    | - Update Azu(CraftyBoxes, Map Details, and Hover Stats)                                                                                                                            |
| 1.0.10    | - Update Jotunn, AzuCraftyBoxes, and AAA Crafting.                                                                                                                                 |
| 1.0.9     | - Update to latest AzuCraftyBoxes                                                                                                                                                  |
| 1.0.8     | - Update to latest Jotunn and AzuCraftyBoxes                                                                                                                                       |
| 1.0.7     | - Add AzuCraftyBoxes, update to latest BepInEx for Valheim  5.4.2105                                                                                                               |
| 1.0.6     | - Update AzuEPI                                                                                                                                                                    |
| 1.0.5     | - Update AAA Crafting and Jotunn                                                                                                                                                   |
| 1.0.4     | - Update AzuEPI                                                                                                                                                                    |
| 1.0.3     | - Update to the latest of each mod.                                                                                                                                                |
| 1.0.2     | - Make sure to target new Jotunn for the mod that relies on it.                                                                                                                    |
| 1.0.1     | - Update some of the dependencies<br/> - Add in SwitchARoo, QueueMeMaybe, and Clutter Sign Component Fix (to fix some mods that might not be updated to the latest sign component) |
| 1.0.0     | - Initial Release                                                                                                                                                                  |