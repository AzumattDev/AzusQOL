> # Update Information (Latest listed first)

| `Version` | `Update Notes`                                                                                                                                                                     |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.7     | - Add AzuCraftyBoxes, update to latest BepInEx for Valheim  5.4.2105                                                                                                               |
| 1.0.6     | - Update AzuEPI                                                                                                                                                                    |
| 1.0.5     | - Update AAA Crafting and Jotunn                                                                                                                                                   |
| 1.0.4     | - Update AzuEPI                                                                                                                                                                    |
| 1.0.3     | - Update to the latest of each mod.                                                                                                                                                |
| 1.0.2     | - Make sure to target new Jotunn for the mod that relies on it.                                                                                                                    |
| 1.0.1     | - Update some of the dependencies<br/> - Add in SwitchARoo, QueueMeMaybe, and Clutter Sign Component Fix (to fix some mods that might not be updated to the latest sign component) |
| 1.0.0     | - Initial Release                                                                                                                                                                  |